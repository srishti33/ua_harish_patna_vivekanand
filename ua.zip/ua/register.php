<?php
session_start();
$conn = mysqli_connect("localhost","root","","foodies");

if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}
if (isset($_POST['submit']))
{
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$location=$_POST['location'];
$mob=$_POST['mob'];
$addr=$_POST['addr'];
$email=$_POST['email'];
$pw=$_POST['pw'];
$cpw=$_POST['cpw'];
$sql = "INSERT INTO user VALUES ('$fname', '$lname', '$location', '$mob', '$addr', '$email', '$pw', '$cpw');";
	if(mysqli_query($conn, $sql))
{  
	$message = "पंजीकरण सफ़ल";
}
else
{  
	$message = "असफल"; 
}
	echo "<script type='text/javascript'>alert('$message');</script>";
	$sql1 = "INSERT INTO php_users_login(`email`, `password`) VALUES ('$email', '$pw');";
	if(mysqli_query($conn, $sql1))
	{  
		$message1 = "डाटाबेस में रखा गया";
	}
	else
	{  
		$message1 = "डाटाबेस असफल";
	}	 
	echo "<script type='text/javascript'>alert('$message1');</script>";}
?>
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
<meta charset="UTF-8">
<TITLE>Register-Foodies</TITLE>
<LINK REL="STYLESHEET" HREF="STYLE.CSS">
	<script type="text/javascript" src="http://www.google.com/jsapi"></script>
	<script type="text/javascript">
          // Load the Google Transliteration API
          google.load("elements", "1", {
                packages: "transliteration"
              });
          function onLoad() {
            var options = {
              sourceLanguage: 'en',
              destinationLanguage: ['hi'],
              shortcutKey: 'ctrl+g',
              transliterationEnabled: true
            };
            // Create an instance on TransliterationControl with the required
            // options.
            var control = new google.elements.transliteration.TransliterationControl(options);
            // Enable transliteration in the textfields with the given ids.
            var ids = [ "fname","lname","mob","location","email","addr","pw","cpw"];
            control.makeTransliteratable(ids);
            // Show the transliteration control which can be used to toggle between
            // English and Hindi and also choose other destination language.
            control.showControl('translControl');
          }
          google.setOnLoadCallback(onLoad);

function validate()
{
	var fname=document.getElementById("fname");
	var lname=document.getElementById("lname");
	var mob=document.getElementById("mob");
	var location=document.getElementById("location");
	var EmailId=document.getElementById("email");
	var addr=document.getElementById("addr");
	var pw=document.getElementById("pw");
	var cpw=document.getElementById("cpw");
	var alphaExp = /[\w\W]+$/;
	var atpos = EmailId.value.indexOf("@");
    var dotpos = EmailId.value.lastIndexOf(".");
 	if(pw.value.length< 8 || cpw.value.length< 8)
	{
		alert("कम से कम 8 अंकों का पासवर्ड दर्ज करें|");
		pw.focus();
		return false;
	}
	else if (pw.value.length != cpw.value.length) 
	{
		alert("पासवर्ड मेल नहीं हो रहा|");
		pw.focus();
        return false;
    }
	else if (pw.value != cpw.value) 
	{
		alert("पासवर्ड मेल नहीं हो रहा|");
		pw.focus();
        return false;
    }
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=EmailId.value.length) 
	{
        alert("Enter valid email-ID");
		EmailId.focus();
        return false;
   	}
	if(fname.value==null || fname.value=="")
	{
		fname.focus();
		alert("Enter valid first name");
		return false;
	}
	if(fname.value.match(alphaExp)){}
	else{
		alert("First name can have only letters");
		fname.focus();
		return false;
	}
	if(lname.value==null || lname.value=="")
	{
		lname.focus();
		alert("Enter valid last name");
		return false;
	}
	if(lname.value.match(alphaExp)){}
	else{
		alert("Last name can have only letters");
		lname.focus();
		return false;
	}
	if(mob.value==null || mob.value==" ")
	{
		alert("Please Enter Mobile Number");
		mob.focus();
		return false;
	}
	if (isNaN(mob.value))
	{
		alert(" Your Mobile Number must be Integers");
		mob.focus();
		return false;
	}
	if((mob.value.length!= 10))
	{
		alert("Enter the valid Mobile Number(Like : 9669666999)");
		mob.focus();
		return false;
	}
	if(location.selectedIndex==0)
	{
		alert("Please select location");
		location.focus();
		return false;		
	}
	if(addr.value==" " || addr.value=="")
	{
		alert("Please Enter Your Address");
		addr.focus();
		return false;
	}
	return true;
}
</SCRIPT>
</HEAD>
<BODY  background="background3.jpg" link="white" alink="white" vlink="white">
<FONT size="4"><NAV align="right">
<A HREF="index.php">मुख्‍य पेज</A>&nbsp&nbsp&nbsp
&nbsp<A HREF="help.php">सहायता</A>&nbsp&nbsp&nbsp<A HREF="register.php">लॉग इन/ पंजीकरण</A></FONT></NAV>
<FORM name="register" method="post" action="register.php" onsubmit="return validate()">
<TABLE border="1" bordercolor="white">
<CAPTION><FONT size="6" color="WHITE">अपना विवरण दर्ज करें </FONT></CAPTION>
<center><div id='translControl' style="width:100px;color:white;">हिंदी में लिखने के लिये ctrl + G दबाएं&nbsp&nbsp</div></center>
<TR class="left">
<TD><FONT size="5" color="WHITE">नाम:</FONT></TD>
<TD><INPUT meta charset="ISO-8859-1" name="fname" type="TEXT" placeholder="नाम दर्ज करें" size="30" maxlength="30" align="center" id="fname"></TD>
</TR>
<TR class="left">
<TD><FONT size="5" color="WHITE">उपनाम:</FONT></TD>
<TD><INPUT type="TEXT" name="lname" align="center" size="30" maxlength="30" placeholder="उपनाम दर्ज करें" id="lname"></TD>
</TR>
<TR class="left">
<TD><FONT size="5" color="WHITE">गन्तव्य:</FONT></TD>
<TD><SELECT name="location" id="location" style="color:#d3d3d3;" onchange="document.postElementById('location').style.color='black';">
<OPTION VALUE="none" disabled selected>------गन्तव्य चुनें--------</OPTION>
<OPTION VALUE="VIT-AP" style="color:black;">राजा बाज़ार</OPTION>
<OPTION VALUE="Mandanam" style="color:black;">बोरिंग रोड</OPTION>
<OPTION VALUE="Alluru" style="color:black;">बेलि रोड</OPTION>
<OPTION VALUE="Thullur" style="color:black;">खजपुरा</OPTION>
</SELECT></TD>
</TR>
<TR class="left">
<TD><FONT size="5" color="WHITE">दूरभाष:</FONT></TD>
<TD><INPUT type="TEXT" name="mob" size="30" maxlength="10" placeholder="दूरभाष दर्ज करें" id="mob"></TD>
</TR>
<TR class="left">
<TD><FONT size="5" color="WHITE">पता:</FONT></TD>
<TD class="left"><TEXTAREA rows="7" cols="33" wrap="physical" placeholder="पता दर्ज करें" id="addr" name="addr"></TEXTAREA></TD>
</TR>
<TR class="left">
<TD><FONT size="5" color="WHITE">ईमेल:</FONT></TD>
<TD><INPUT name="email" type="TEXT" id="email" placeholder="ईमेल दर्ज करें" size="30" maxlength="30"></TD>
</TR>
<TR class="left">
<TD><FONT size="5" color="WHITE">पासवर्ड:</FONT></TD>
<TD><INPUT type="PASSWORD" name="pw" size="30"  id="pw"></TD>
</TR>
<TR class="left">
<TD><FONT size="5" color="WHITE">पासवर्ड सुनिश्चित करें:</FONT></TD>
<TD><INPUT type="PASSWORD" name="cpw" size="30" id="cpw"></TD>
</TR>
<TR class="left">
<TD colspan="2"><FONT size="4" color="WHITE">
<INPUT type="checkbox" name="tc" value="tc">
मैं नियम एवं शर्तों से सहमत हुं|<BR>&nbsp&nbsp&nbsp&nbsp&nbsp</FONT></TD>
</TR>
</TABLE>
<P><INPUT TYPE="Submit" value="दर्ज करें" name="submit" id="submit" class="button" onclick="if(!this.form.tc.checked){alert('You must agree to the terms first.');return false}">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<INPUT TYPE="Reset" value="पुनः भरें" id="reset" class="button"></P></FORM>
<HR width="1000">
<FORM action="login.php">
<P align="CENTER"><FONT size="6" color="white" face="Arial">
खाता पहले से बना हॅ?<BR></FONT>
<INPUT TYPE="submit" value="लॉग इन करें" id="login" class="button">
</P>
</FORM>
</BODY>
</HTML>